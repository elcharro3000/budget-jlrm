import Dashboard from './Dashboard'
export default function ReportPage(){ return (<div><Dashboard /></div>) }
